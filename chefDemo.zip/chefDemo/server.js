/****************************
 SERVER MAIN FILE
 ****************************/

// need to add in case of self-signed certificate connection
process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0;

// Include Modules
const exp = require('express');
const config = require('./configs/configs');
const express = require('./configs/express');
const mongoose = require('./configs/mongoose');
const path = require('path');
const fs = require('fs');
const cronService = require('./app/services/Cron');
const i18n = require("i18n");
i18n.configure({
    locales: ['en', 'es', 'de'],
    directory: __dirname + '/app/locales',
    defaultLocale: 'en'
});
const swaggerUi = require('swagger-ui-express');

// HTTP Authentication
const basicAuth = require('basic-auth');
const auth = function (req, res, next) {
    const user = basicAuth(req);
    if (!user || !user.name || !user.pass) {
        res.set('WWW-Authenticate', 'Basic realm=Authorization Required');
        res.sendStatus(401);
        return;
    }
    if (user.name === config.HTTPAuthUser && user.pass === config.HTTPAuthPassword) {
        next();
    } else {
        res.set('WWW-Authenticate', 'Basic realm=Authorization Required');
        res.sendStatus(401);
        return;
    }
}

global.appRoot = path.resolve(__dirname);

db = mongoose();
const app = express();

app.get('/', function (req, res, next) {
    res.send('hello world');
});

/* Old path for serving public folder */
app.use('/public', exp.static(__dirname + '/public'));

if (process.env.NODE_ENV !== 'Production') {
    const options = {
        customCss: '.swagger-ui .models { display: none }'
    };
    const mainSwaggerData = JSON.parse(fs.readFileSync('swagger.json'));
    mainSwaggerData.host = config.host;
    //mainSwaggerData.host = config.host + ':' + config.serverPort;
    mainSwaggerData.basePath = config.baseApiUrl;

    const modules = './app/modules';
    fs.readdirSync(modules).forEach(file => {
        if (fs.existsSync(modules + '/' + file + '/swagger.json')) {
            const stats = fs.statSync(modules + '/' + file + '/swagger.json');
            const fileSizeInBytes = stats.size;
            if (fileSizeInBytes) {
                let swaggerData = fs.readFileSync(modules + '/' + file + '/swagger.json');
                swaggerData = swaggerData ? JSON.parse(swaggerData) : { paths: {}, definitions: {} };
                mainSwaggerData.paths = { ...swaggerData.paths, ...mainSwaggerData.paths };
                mainSwaggerData.definitions = { ...swaggerData.definitions, ...mainSwaggerData.definitions };
            }
        }
    });
    if (config.isHTTPAuthForSwagger) {
        app.get("/docs", auth, (req, res, next) => {
            next();
        });
    }
    const swaggerDocument = mainSwaggerData;
    app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument, options));
}

(new cronService()).scheduleLiveClassMailReminder();
// configure https for listening server.

// const httpsoptions = {
//     key: fs.readFileSync('server-key.pem'),
//     cert: fs.readFileSync('server-cert.pem')
// };


// app.get('*', function (req, res) {
//     res.redirect('https://' + req.headers.host + req.url);
// });
// https.createServer(httpsoptions, app).listen(config.serverPort, () => {
//     console.log('process.env.NODE_ENV', process.env.NODE_ENV);
//     console.log(`Server running at https://localhost:${config.serverPort}`);
// });


// Listening Server
app.listen(config.serverPort, async () => {
    console.log('process.env.NODE_ENV', process.env.NODE_ENV);
    console.log(`Server running at http://localhost:${config.serverPort}`);
});
