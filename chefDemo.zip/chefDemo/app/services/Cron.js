/****************************
 SCHEDULE CRON JOBS
 ****************************/
const cron = require('node-cron')
const Recipe = require('../modules/Recipe/Schema').Recipe
const Chef = require('../modules/Chef/Schema').Chef
const Moment = require('moment')
const Email = require('./Email')
class Cron {

    constructor() { }

    scheduleLiveClassMailReminder() {
        console.log('ENTER: scheduleRecipeMailReminder()')
        cron.schedule('* * * * *', async () => {
            try {
                const recipeList = await Recipe.find({ isDeleted: false, type: 'LIVE_CLASS' }).select({ _id: 0, attendees: 1, classStartTime: 1, title: 1 })
                recipeList.map(async recipe => {
                    // check for only 30 minutes remains for class to begin
                    if (Moment().seconds(0).milliseconds(0).isSame(Moment(recipe.classStartTime).subtract(30, "minutes"))) {
                        const chefList = await Chef.find({ _id: { $in: recipe.attendees }, isDeleted: false }).select({ _id: 0, emailId: 1 })
                        chefList.map(async chef => {
                            const mailData = {
                                emailKey: 'live_class_reminder_mail',
                                emailId: chef.emailId,
                                replaceDataObj: { classTitle: recipe.title }
                            }
                            const mailResponse = await new Email().sendMail(mailData)
                            console.log('mailResponse = ', mailResponse)
                        })
                    }
                })
                console.log('EXIT: scheduleRecipeMailReminder()')
            } catch (error) {
                console.log('Error in scheduleRecipeMailReminder(). Error =', error)
            }
        })
    }
}

module.exports = Cron