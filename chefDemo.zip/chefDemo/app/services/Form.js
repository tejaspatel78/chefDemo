/****************************
 FORM HANDLING OPERATIONS
 ****************************/
const multiparty = require('multiparty');
class Form {
    constructor(request) {
        this.request = request;
    }

    // Method to parse the form data
    parse() {
        return new Promise(async (resolve, reject) => {
            try {
                const form = new multiparty.Form();
                // Parsing the form
                form.parse(this.request, (err, fields, files) => {
                    if (err) {
                        return reject({ message: err, status: 0 });
                    }
                    const formParseObject = {};
                    formParseObject.fields = fields;
                    formParseObject.files = files;
                    return resolve(formParseObject);
                });
            } catch (error) {
                return reject(error)
            }
        });
    }
}

module.exports = Form;