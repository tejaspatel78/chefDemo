/****************************
 FILE HANDLING OPERATIONS
 ****************************/
const fs = require('fs');
const _ = require("lodash");
const mv = require('mv');
const aws = require('aws-sdk');
const Jimp = require('jimp');

aws.config.update({
    secretAccessKey: 'x+gtkqR6CS1y5dWhgqbJhivFlYKXXwUmoMqCecbz',
    accessKeyId: 'AKIA3N3636PYDYBE3F6O',
    region: 'ap-south-1'
});

const s3 = new aws.S3();


class File {

    constructor(file, location) {
        this.file = file;
        this.location = location;
    }

    // Method to Store file
    store(id, data) {
        return new Promise((resolve, reject) => {
            if (_.isEmpty(this.file.file)) {
                reject('Please send file.');
            }
            const fileName = this.file.file[0].originalFilename.split(".");
            const ext = _.last(fileName);
            const imagePath = data && data.imagePath ? data.imagePath : '/public/upload/images/';
            const filePath = id + '/' + 'image_' + Date.now().toString() + '.' + ext;
            const uploadFilePath = imagePath + filePath;
            const fileObject = { 'file': filePath };
            mv(this.file.file[0].path, appRoot + uploadFilePath, { mkdirp: true }, function (err) {
                if (err) {
                    reject(err);
                }
                resolve(fileObject);
            });
        });

    }
    
    uploadFileOnS3(file) {
        const fileName = file.originalFilename.split(".");
        const newFileName = fileName[0] + Date.now().toString() + '.' + fileName[1];
        return new Promise((resolve, reject) => {
            s3.createBucket(() => {
                const params = {
                    Bucket: 'agent-phase-2',
                    Key: newFileName,
                    Body: fs.createReadStream(file.path),
                    ACL: "public-read",
                }
                s3.upload(params, function (err, data) {
                    if (err) {
                        reject(err);
                    } else {
                        console.log('s3upload response =', data)
                        resolve(data);
                    }
                });
            });
        });
    }

    /****************************************************** 
    image upload code for image compression and image resizing
    scaleToFit(width, height) for resizing the image, set width and height  of the image according to your requirement
    quality(40) for image compression
    If you don't want any of these you can simply remove this.
    **************************************************************/
    saveImage(data) {
        return new Promise(async (resolve, reject) => {
            await Jimp.read(this.file.file[0].path).then(async (image1) => {
                const fileName = this.file.file[0].originalFilename.split(".");
                const ext = _.last(fileName);
                const imagePath = data && data.imagePath ? data.imagePath : '/public/upload/images/';
                const name = 'image_' + Date.now().toString() + '.' + ext;
                const filePath = appRoot + imagePath + name;
                const fileObject = { 'file': name };
                await image1.quality(50).scaleToFit(600, 600).write(filePath, async () => {
                    return resolve(fileObject)
                });
            }).catch(err => {
                reject(err)
            });
        });
    }
}

module.exports = File;