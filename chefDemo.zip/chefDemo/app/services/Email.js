/****************************
 EMAIL HANDLING OPERATIONS
 ****************************/
const nodemailer = require('nodemailer');
const config = require("../../configs/configs");
const Mustache = require('mustache');
const EmailTemplate = require('../modules/EmailTemplate/Schema').EmailTemplate;

const smtpTransport = nodemailer.createTransport({
    pool: true,
    host: "smtp.gmail.com",
    port: 587,
    secure: false, // use TLS,
    auth: {
        user: 'meanstack2017@gmail.com',
        pass: 'Mean@123'
    },
    debug: true
});


class Email {

    send(mailOption) {
        return new Promise(async (resolve, reject) => {
            smtpTransport.sendMail(mailOption, (error, result) => {
                if (error) {
                    console.log('Error =', error);
                    return reject({ status: 0, message: error });
                }
                return resolve(result);
            });
        });
    }

    sendMail(mailData) {
        return new Promise(async (resolve, reject) => {
            try {
                const emailTemplate = await EmailTemplate.findOne({ emailKey: mailData.emailKey });
                if (emailTemplate) {
                    const mailOptions = {
                        from: config.defaultEmailId,
                        to: mailData.emailId ? mailData.emailId : [],
                        subject: emailTemplate.subject ? emailTemplate.subject : "Subject",
                        html: Mustache.render(emailTemplate.emailContent, mailData.replaceDataObj)
                    }
                    const result = await new Email().send(mailOptions);
                    return resolve(result);
                } else {
                    return resolve({ status: 0, message: "Signup mail template not found." })
                }
            } catch (error) {
                return reject(error);
            }
        });
    }
}

module.exports = Email;