const Controller = require("../Base/Controller")
const _ = require("lodash")
const Chef = require('./Schema').Chef
const Email = require('../../services/Email')
const Model = require("../Base/Model")
const chefProjection = require('./Projection')
const Globals = require("../../../configs/Globals")
const Config = require("../../../configs/configs")
const Authentication = require('../Authentication/Schema').Authtokens
const CommonService = require("../../services/Common")
const i18n = require("i18n")
const Form = require("../../services/Form")
const File = require("../../services/File")
const Transaction = require('mongoose-transactions')


class ChefController extends Controller {
    constructor() {
        super()
    }

    /********************************************************
    Purpose: chef register
    Parameter:
       {
            "emailId":"john@gmail.com",
            "password":"john",
            "mobile":"9876543219",
            "firstname":"john",
            "lastname":"deo"
        }
    Return: JSON String
    ********************************************************/
    async register() {
        const transaction = new Transaction()
        try {
            const reqPayload = this.req.body
            // check emailId is exist or not
            const chef = await Chef.findOne({ 'emailId': this.req.body.emailId.toLowerCase() })
            // if chef exist give error
            if (!_.isEmpty(chef)) {
                return this.res.send({ status: 0, message: i18n.__("EMAIL_EXIST") })
            }
            const encryptedPassword = await (new CommonService()).ecryptPassword({ password: reqPayload.password })
            reqPayload.emailId = reqPayload.emailId.toLowerCase()
            reqPayload.password = encryptedPassword
            // save new chef data
            const newChefData = await new Model(Chef).store(reqPayload)
            // if chef data is empty give error message.
            if (_.isEmpty(newChefData)) {
                return this.res.send({ status: 0, message: i18n.__('CHEF_NOT_SAVED') })
            }
            const verificationToken = await new Globals().generateToken(newChefData._id)
            //sending mail to verify chef
            const emailData = {
                emailId: reqPayload.emailId,
                emailKey: 'signup_mail',
                replaceDataObj: { fullName: reqPayload.firstname + " " + reqPayload.lastname, verificationLink: Config.rootUrl + '/chef/verifyChef?token=' + verificationToken }
            }
            const mailResponse = await new Email().sendMail(emailData)
            if (mailResponse && mailResponse.status === 0) {
                transaction.rollback()
                return this.res.send(mailResponse)
            } else if (mailResponse && !mailResponse.response) {
                transaction.rollback()
                return this.res.send({ status: 0, message: i18n.__('MAIL_NOT_SEND_SUCCESSFULLY') })
            }
            transaction.update('Chef', newChefData._id, { verificationToken: verificationToken, verificationTokenCreationTime: new Date() })
            await transaction.run()
            return this.res.send({ status: 1, message: i18n.__('REGISTRATION_SUCCESS') })
        } catch (error) {
            console.log("Error while register(). Error = ", error)
            return this.res.send({ status: 0, message: error })
        }
    }

    /********************************************************
    Purpose: Forgot password mail
    Parameter:
        {
            "emailId":"john@doe.com"
        }
    Return: JSON String
    ********************************************************/
    async forgotPasswordMail() {
        try {
            const chef = await Chef.findOne({ emailId: this.req.body.emailId })
            if (_.isEmpty(chef)) {
                return this.res.send({ status: 0, message: i18n.__("EMAIL_NOT_EXIST") })
            }
            const token = await new Globals().generateToken(chef._id)
            const emailData = {
                emailId: chef.emailId,
                emailKey: 'forgot_password_mail',
                replaceDataObj: { fullName: chef.firstname + " " + chef.lastname, resetPasswordLink: Config.frontUrlAngular + '?token=' + token }
            }
            const sendingMail = await new Email().sendMail(emailData)
            if (sendingMail && sendingMail.status === 0) {
                return this.res.send(sendingMail)
            } else if (sendingMail && !sendingMail.response) {
                return this.res.send({ status: 0, message: i18n.__("SERVER_ERROR") })
            }
            await Chef.findByIdAndUpdate(chef._id, { forgotToken: token, forgotTokenCreationTime: new Date() })
            return this.res.send({ status: 1, message: i18n.__("FORGOT_PASS_MAIL_SENT_SUCCESSFULLY") })
        } catch (error) {
            console.log("Error while forgotPasswordMail(). Error = ", error)
            this.res.send({ status: 0, message: error })
        }
    }
    
    /********************************************************
    Purpose: Reset password
    Parameter:
        {
            "password":"PASS1234",
            "token": "tfstfdrytrrwqqqsssfdfvfgfdewwwww"
        }
    Return: JSON String
   ********************************************************/
    async resetPassword() {
        try {
            const chef = await Chef.findOne({ forgotToken: this.req.body.token })
            if (_.isEmpty(chef)) {
                return this.res.send({ status: 0, message: i18n.__("INVALID_TOKEN") })
            }
            const decoded = await Globals.decodeChefForgotToken(chef)
            if (!decoded) {
                return this.res.send({ status: 0, message: i18n.__("LINK_EXPIRED") })
            }
            const password = await (new CommonService()).ecryptPassword({ password: this.req.body.password })
            const updatedChefData = await Chef.findByIdAndUpdate(chef._id, { password: password }, { new: true })
            if (_.isEmpty(updatedChefData)) {
                return this.res.send({ status: 0, message: i18n.__("PASSWORD_NOT_UPDATED") })
            }
            return this.res.send({ status: 1, message: i18n.__("PASSWORD_UPDATED_SUCCESSFULLY") })
        } catch (error) {
            console.log("Error while resetPassword(). Error = ", error)
            this.res.send({ status: 0, message: error })
        }
    }

    /********************************************************
    Purpose: Login
    Parameter:
        {
            "emailId":"john@doe.com"
            "password":"123456",
        }
    Return: JSON String
   ********************************************************/
    async login() {
        try {
            let chef = await Chef.findOne({ emailId: this.req.body.emailId.toString().toLowerCase(), status: true, isDeleted: false })
            if (_.isEmpty(chef)) {
                return this.res.send({ status: 0, message: i18n.__("CHEF_NOT_EXIST_OR_BLOCKED") })
            } else if (!chef.emailVerificationStatus) {
                return this.res.send({ status: 0, message: i18n.__("VERIFY_EMAIL") })
            }
            const status = await new CommonService().verifyPassword({ password: this.req.body.password, savedPassword: chef.password })
            if (!status) {
                return this.res.send({ status: 0, message: i18n.__("INVALID_PASSWORD") })
            }
            // remove unwanted properties
            chef = JSON.parse(JSON.stringify(chef))
            chef = _.omit(chef, Object.keys(chefProjection.chef))
            if (Config.useRefreshToken) {
                const { token, refreshToken } = await new Globals().getTokenWithRefreshToken({ id: chef._id })
                return this.res.send({ status: 1, message: i18n.__("LOGIN_SUCCESS"), access_token: token, refreshToken: refreshToken, data: chef })
            } else {
                const token = await new Globals().getToken({ id: chef._id })
                return this.res.send({ status: 1, message: i18n.__("LOGIN_SUCCESS"), access_token: token, data: chef })
            }
        } catch (error) {
            console.log('Error while login(). Error =', error)
            this.res.send({ status: 0, message: i18n.__('SERVER_ERROR') })
        }
    }

    /********************************************************
    Purpose: Change Password
    Parameter:
        {
            "oldPassword":"password",
            "newPassword":"newpassword"
        }
    Return: JSON String
   ********************************************************/
    async changePassword() {
        try {
            const currentUser = this.req.currentUser
            const passwordObj = {
                oldPassword: this.req.body.oldPassword,
                newPassword: this.req.body.newPassword,
                savedPassword: currentUser.password
            }
            const password = await (new CommonService()).changePasswordValidation(passwordObj)
            if (password && password.status === 0) {
                return this.res.send(password)
            }
            const updatedChefData = await Chef.findByIdAndUpdate(currentUser._id, { password: password }, { new: true })
            return _.isEmpty(updatedChefData) ? this.res.send({ status: 0, message: i18n.__("PASSWORD_NOT_UPDATED") }) : this.res.send({ status: 1, message: i18n.__("PASSWORD_UPDATED_SUCCESSFULLY") })
        } catch (error) {
            console.log("Error while changePassword(). Error = ", error)
            return this.res.send({ status: 0, message: error })
        }
    }

    /********************************************************
    Purpose: Edit profile
    Body Parameter:
        {
            "publicProfile": true,
            "username": "username",
            "occupation": "chef",
            "restaurantName": "KFC",
            "bio": "An professional chef",
            "coverImage": "coverImage"
        }
    /////////////// or ////////////////
        {
            "publicProfile": false,
            "firstname": "firstname",
            "lastname": "lastname",
            "emailId": "email@gmail.com"
            "mobile": "9898989898",
            "photo": "photo"
        }
    
    Return: JSON String
   ********************************************************/
    async editChefProfile() {
        try {
            const currentUserId = this.req.currentUser && this.req.currentUser._id ? this.req.currentUser._id : ""
            const updatedChef = await Chef.findByIdAndUpdate(currentUserId, this.req.body, { new: true }).select(chefProjection.chef)
            return this.res.send({ status: 1, message: i18n.__("CHEF_UPDATED_SUCCESSFULLY"), data: updatedChef })
        } catch (error) {
            console.log("Error while editChefProfile(). Error = ", error)
            this.res.send({ status: 0, message: i18n.__("SERVER_ERROR") })
        }
    }

    /********************************************************
    Purpose: get chef details
    Parameter:
    {
        "_id": "5ad5d198f657ca54cfe39ba0"
    }
    Return: JSON String
    ********************************************************/
    async chefProfile() {
        try {
            const chefId = this.req.currentUser && this.req.currentUser._id ? this.req.currentUser._id : ''
            const chef = await Chef.findOne({ _id: chefId }, chefProjection.chef)
            return _.isEmpty(chef) ? this.res.send({ status: 0, message: i18n.__("CHEF_NOT_EXIST") }) : this.res.send({ status: 1, data: chef })
        } catch (error) {
            console.log("Error while chefProfile. Error = ", error)
            this.res.send({ status: 0, message: error })
        }
    }

    /********************************************************
    Purpose: verify chef
    Parameter:
    {
        token:"eftyvyvjbshbhbhbjsvctvtvzvtsvtbytvyvy"
    }
    Return: JSON String
    ********************************************************/
    async verifyChef() {
        try {
            const chef = await Chef.findOne({ verificationToken: this.req.query.token })
            if (_.isEmpty(chef)) {
                return this.res.send({ status: 0, message: i18n.__("INVALID_TOKEN") })
            }
            const decoded = await Globals.decodeChefVerificationToken(chef)
            if (!decoded) {
                return this.res.send({ status: 0, message: i18n.__("LINK_EXPIRED") })
            }
            const updateChefData = await Chef.findByIdAndUpdate(chef._id, { emailVerificationStatus: true }, { new: true })
            if (_.isEmpty(updateChefData)) {
                return this.res.send({ status: 0, message: i18n.__("CHEF_NOT_UPDATED") })
            }
            return this.res.send({ status: 1, message: i18n.__("CHEF_VERIFIED") })
        } catch (error) {
            console.log("Error while verifyChef(). Error = ", error)
            return this.res.send({ status: 0, message: i18n.__("SERVER_ERROR") })
        }
    }

    /********************************************************
    Purpose: Logout User
    Parameter: {}
    Return: JSON String
    ********************************************************/
    async logout() {
        try {
            const currentUser = this.req.currentUser ? this.req.currentUser : {}
            if (currentUser && currentUser._id) {
                await Authentication.update({ chefId: currentUser._id }, { $set: { token: null } })
                this.res.send({ status: 1, message: i18n.__("LOGOUT_SUCCESS") })
            } else {
                return this.res.send({ status: 0, message: i18n.__("CHEF_NOT_EXIST") })
            }

        } catch (error) {
            console.log('Error while logout(). Error = ', error)
            this.res.send({ status: 0, message: error })
        }
    }

    /********************************************************
    Purpose: Single File uploading
    Parameter:
    {
        "file": File
    }
    Return: JSON String
    ********************************************************/
    async fileUpload() {
        try {
            const currentUserId = this.req.currentUser && this.req.currentUser._id ? this.req.currentUser._id : ''
            const formObject = await new Form(this.req).parse()
            if (_.isEmpty(formObject.files)) {
                return this.res.send({ status: 0, message: i18n.__("%s REQUIRED", 'File') })
            }
            const file = new File(formObject.files)
            let fileObject = ''
            if (Config.s3upload && Config.s3upload === 'true') {
                fileObject = await file.uploadFileOnS3(formObject.files.file[0])
            } else {
                fileObject = await file.store(currentUserId)
                /**** uncomment this line to do manipulations in image like compression and resizing ****/
                // fileObject = await file.saveImage()
            }
            this.res.send({ status: 1, data: fileObject })
        } catch (error) {
            console.log("Error while fileUpload(). Error = ", error)
            this.res.send({ status: 0, message: error })
        }
    }

    /********************************************************
    Purpose: social Access (both signUp and signIn)
    Parameter:
        {
            "socialId":"12343434234",
            "socialKey":"googleId"
            "mobile":"9876558788",
            "emailId":"john@grr.la",
            "firstname":"john",
            "lastname":"deo",
            "username":"john123"
        }
    Return: JSON String
    ********************************************************/
    async socialAccess() {
        try {
            /***** storing every details coming from request body ********/
            const details = this.req.body

            /****** dynamic socialKey (socialKey may be fbId, googleId, twitterId, instagramId) ********/
            details[details.socialKey] = details.socialId

            /***** checking whether we are getting proper socialKey or not ******/
            const checkingSocialKey = _.includes(['fbId', 'googleId'], details.socialKey)
            if (!checkingSocialKey) {
                return this.res.send({ status: 0, message: i18n.__("PROVIDE_PROPER_SOCIALKEY") })
            }
            /****** query for checking socialId is existing or not *********/
            const filter = { [details.socialKey]: this.req.body.socialId }

            /**** checking chef is existing or not *******/
            const chef = await Chef.findOne(filter, chefProjection.chef)

            /**** if chef not exists with socialId *****/
            if (_.isEmpty(chef)) {

                if (this.req.body.emailId) {
                    /******** checking whether chef is already exists with emailId or not *******/
                    const chefDetails = await Chef.findOne({ emailId: this.req.body.emailId }, chefProjection.chef)

                    /****** If chef not exists with above emailId *******/
                    if (_.isEmpty(chefDetails)) {
                        /******** This is the signUp process for socialAccess with emailId *****/
                        const newChefResponse = await this.createSocialUser(details)
                        return this.res.send(newChefResponse)
                    }
                    else {
                        /**** social access code *****/
                        const updatedChefResponse = await this.checkingSocialIdAndUpdate(chefDetails, details)
                        return this.res.send(updatedChefResponse)
                    }
                }
                else {
                    /******** This is the signUp process for socialAccess without emailId *****/
                    const newChef = await this.createSocialUser(details)
                    return this.res.send(newChef)
                }
            }
            /****** if chef exists with socialId ******/
            else {
                if (this.req.body.emailId) {
                    /******** to check whether is already exists with emailId or not *******/
                    const chefDetails = await Chef.findOne({ emailId: this.req.body.emailId })
                    /****** If chef not exists with above emailId *******/
                    if (_.isEmpty(chefDetails)) {
                        /****** updating details in existing chef with emailid details *****/
                        const updatedChefResponse = await this.updateSocialChefDetails(details)
                        return this.res.send(updatedChefResponse)
                    } else {
                        /**** social access code *****/
                        const updatedChefResponse = await this.checkingSocialIdAndUpdate(chefDetails, details)
                        return this.res.send(updatedChefResponse)
                    }
                }
                else {
                    /****** updating details in existing chef details ********/
                    const updatedChefResponse = await this.updateSocialChefDetails(details)
                    return this.res.send(updatedChefResponse)
                }
            }
        } catch (error) {
            console.log('Error while socialAccess(). Error = ', error)
            this.res.send({ status: 0, message: error })
        }
}

    /******** Create Chef through socialIds ******/
    createSocialUser(details) {
        return new Promise(async (resolve, reject) => {
            try {
                const newChef = await new Model(Chef).store(details)
                const token = await (new Globals()).getToken({ id: newChef._id })
                resolve({ status: 1, message: i18n.__("LOGIN_SUCCESS"), access_token: token, data: newChef })
            } catch (error) {
                reject(error)
            }
        })
    }

    /******** Create Chef through socialIds ******/
    updateSocialChefDetails(details) {
        return new Promise(async (resolve, reject) => {
            try {
                const updatedChef = await Chef.findOneAndUpdate({ [details.socialKey]: details.socialId }, details, { upsert: true, new: true }).select(chefProjection.chef)
                const token = await (new Globals()).getToken({ id: updatedChef._id })
                resolve({ status: 1, message: i18n.__("LOGIN_SUCCESS"), access_token: token, data: updatedChef })
            } catch (error) {
                reject(error)
            }
        })
    }

    /******* Create Chef through socialIds ******/
    checkingSocialIdAndUpdate(chefDetails, details) {
        return new Promise(async (resolve, reject) => {
            try {
                if (chefDetails[details.socialKey] && chefDetails[details.socialKey] !== details.socialId) {
                    resolve({ status: 0, message: i18n.__("LINK_WITH_ANOTHER_SOCIAL_ACCOUNT") })
                }
                /****** updating details in existing chef with emailId details *******/
                const updatedChef = await Chef.findOneAndUpdate({ emailId: details.emailId }, details, { upsert: true, new: true }).select(chefProjection.chef)
                const token = await (new Globals()).getToken({ id: updatedChef._id })
                resolve({ status: 1, message: i18n.__("LOGIN_SUCCESS"), access_token: token, data: updatedChef })
            } catch (error) {
                reject(error)
            }
        })
    }
}

module.exports = ChefController