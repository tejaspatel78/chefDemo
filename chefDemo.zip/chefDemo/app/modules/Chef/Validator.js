/****************************
 Validators
 ****************************/
const i18n = require("i18n");
const {
    check,
    query,
    validationResult
} = require('express-validator');
const commonlyUsedPasswords = require('../../../configs/commonlyUsedPassword').passwords;

class Validators {

    /********************************************************
    Purpose:Function for login validator
    Parameter:
    {}
    Return: JSON String
    ********************************************************/
    static loginValidator() {
        try {
            return [
                ...this.emailValidator(),
                ...this.passwordValidator({
                    key: 'password'
                })
            ];
        } catch (error) {
            return error;
        }
    }

    /********************************************************
    Purpose:Function for signup validator
    Parameter:
    {}
    Return: JSON String
    ********************************************************/
    static chefSignupValidator() {
        try {
            return [
                ...this.emailValidator(),
                ...this.basicInfoValidator(),
                ...this.passwordValidator({
                    key: 'password'
                })
            ];
        } catch (error) {
            return error;
        }
    }

    /********************************************************
    Purpose:Function for reset password validator
    Parameter:
    {}
    Return: JSON String
    ********************************************************/
    static resetPasswordValidator() {
        try {
            return [
                check('token').exists().withMessage(i18n.__("%s REQUIRED", 'Token')),
                ...this.passwordValidator({
                    key: 'password'
                })
            ];
        } catch (error) {
            return error;
        }
    }

    /********************************************************
    Purpose:Function for password validator
    Parameter:
    {}
    Return: JSON String
    ********************************************************/
    static passwordValidator(keyObj = {
        key: 'password'
    }) {
        try {
            return [
                check(keyObj.key)
                .not().isIn(commonlyUsedPasswords).withMessage(i18n.__("COMMONLY_USED_PASSWORD"))
                .isLength({
                    min: 8
                }).withMessage(i18n.__("PASSWORD_VALIDATION_LENGTH"))
                .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d].*/).withMessage(i18n.__("PASSWORD_VALIDATION"))
            ];
        } catch (error) {
            return error;
        }
    }

    /********************************************************
    Purpose:Function for email validator
    Parameter:
    {}
    Return: JSON String
    ********************************************************/
    static emailValidator() {
        try {
            return [check('emailId').isEmail().withMessage(i18n.__("INVALID_EMAIL"))];
        } catch (error) {
            return error;
        }
    }

    /********************************************************
    Purpose:Function for basic info validator
    Parameter:
    {}
    Return: JSON String
    ********************************************************/
    static basicInfoValidator() {
        try {
            return [
                check('firstname').exists().withMessage(i18n.__("%s REQUIRED", 'Firstname')),
                check('lastname').exists().withMessage(i18n.__("%s REQUIRED", 'Lastname')),
                check('mobile').exists().withMessage(i18n.__("%s REQUIRED", 'Mobile'))
            ];
        } catch (error) {
            return error;
        }
    }
 
    /********************************************************
    Purpose: Function for change password validator
    Parameter:
    {}
    Return: JSON String
    ********************************************************/
    static changePasswordValidator() {
        try {
            return [
                check('oldPassword').exists().withMessage(i18n.__("%s REQUIRED", 'Current password')),
                ...this.passwordValidator({
                    key: 'newPassword'
                })
            ];
        } catch (error) {
            return error;
        }
    }
 
    /********************************************************
    Purpose:Function for update chef validator
    Parameter:
    {}
    Return: JSON String
    ********************************************************/
    static updateChefValidator() {
        try {
            return check('publicProfile')
            .exists()
            .withMessage(i18n.__("%s REQUIRED", 'publicProfile'))
            .custom((publicProfile, { req }) => {
                const keyArray = Object.keys(req.body)
                if (publicProfile === true) {
                    if (!keyArray.includes('username')) {
                        throw new Error(i18n.__("%s REQUIRED", 'username'))
                    }
                return true
                } else if (publicProfile === false) {
                    const difference = ['firstname', 'lastname', 'mobile', 'emailId'].filter(obj => !keyArray.includes(obj))
                    if (difference.length > 0) {
                        throw new Error(i18n.__("%s REQUIRED", difference.toString()));
                    }
                return true
                } else {
                    return true
                }
            })
        } catch (error) {
            return error;
        }
    }

    /********************************************************
    Purpose:Function for verify chef validator
    Parameter:
    {}
    Return: JSON String
    ********************************************************/
    static verifyChefValidator() {
        try {
            return [
                query('token').exists().withMessage(i18n.__("%s REQUIRED", 'Token'))
            ];
        } catch (error) {
            return error;
        }
    }

    /********************************************************
    Purpose: Social Access validator
    Parameter:
    {}
    Return: JSON String
    ********************************************************/
    static socialAccessValidator() {
        try {
            return [
                check('socialId').exists().withMessage(i18n.__("%s REQUIRED", 'socialId')),
                check('socialKey').exists().withMessage(i18n.__("%s REQUIRED", 'socialKey')),
            ];
        } catch (error) {
            return error;
        }
    }

    static validate(req, res, next) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(422).json({
                    status: 0,
                    message: errors.array()
                });
            }
            next();
        } catch (error) {
            return res.send({
                status: 0,
                message: error
            });
        }
    }
}

module.exports = Validators;