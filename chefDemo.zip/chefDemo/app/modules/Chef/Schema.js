const mongoose = require('mongoose');
const schema = mongoose.Schema;

const chef = new schema({
    firstname: { type: String, required: true },
    lastname: { type: String, required: true },
    username: { type: String },
    emailId: { type: String, required: true, unique: true },
    password: { type: Buffer },
    photo: { type: String, required: false },
    emailVerificationStatus: { type: Boolean, default: false },
    isDeleted: { type: Boolean, default: false },
    status: { type: Boolean, default: true },
    mobile: { type: String },
    fbId: { type: String },
    googleId: { type: String },
    verificationToken: { type: String },
    verificationTokenCreationTime: { type: Date },
    forgotToken: { type: String },
    forgotTokenCreationTime: { type: Date },
    occupation: { type: String, required: false },
    restaurantName: { type: String, required: false },
    bio: { type: String, required: false },
    coverImage: { type: String, required: false },
}, {
        timestamps: true
    });


let Chef = mongoose.model('Chef', chef);
module.exports = {
    Chef,
    chef
}