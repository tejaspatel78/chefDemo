
module.exports = (app, express) => {

    const router = express.Router();
    const Globals = require("../../../configs/Globals");
    const ChefController = require('./Controller');
    const config = require('../../../configs/configs');
    const Validators = require("./Validator");

    router.post('/chef/register', Validators.chefSignupValidator(), Validators.validate, function (req, res) {
        const chefObj = (new ChefController()).boot(req, res);
        return chefObj.register();
    });

    router.post('/chef/login', Validators.loginValidator(), Validators.validate, (req, res) => {
        const chefObj = (new ChefController()).boot(req, res);
        return chefObj.login();
    });

    router.get('/chef/profile', Globals.isAuthorised, (req, res) => {
        const chefObj = (new ChefController()).boot(req, res);
        return chefObj.chefProfile();
    });

    router.get('/chef/verifyChef', Validators.verifyChefValidator(), Validators.validate, (req, res) => {
        const chefObj = (new ChefController()).boot(req, res);
        return chefObj.verifyChef();
    });
    
    router.post('/chef/updateChefProfile', Globals.isAuthorised, Validators.updateChefValidator(), Validators.validate, (req, res) => {
        const chefObj = (new ChefController()).boot(req, res);
        return chefObj.editChefProfile();
    });
    
    router.post('/chef/forgotPassword', Validators.emailValidator(), Validators.validate, (req, res) => {
        const chefObj = (new ChefController()).boot(req, res);
        return chefObj.forgotPasswordMail();
    });

    router.post('/chef/resetPassword', Validators.resetPasswordValidator(), Validators.validate, (req, res) => {
        const chefObj = (new ChefController()).boot(req, res);
        return chefObj.resetPassword();
    });

    router.post('/chef/changePassword', Globals.isAuthorised, Validators.changePasswordValidator(), Validators.validate, (req, res) => {
        const chefObj = (new ChefController()).boot(req, res);
        return chefObj.changePassword();
    });

    router.post('/chef/fileUpload', Globals.isAuthorised, (req, res) => {
        const chefObj = (new ChefController()).boot(req, res);
        return chefObj.fileUpload();
    });

    router.post('/chef/socialAccess', Validators.socialAccessValidator(), Validators.validate, (req, res, next) => {
        const chefObj = (new ChefController()).boot(req, res);
        return chefObj.socialAccess();
    });

    router.get('/chef/logout', Globals.isAuthorised, (req, res) => {
        const chefObj = (new ChefController()).boot(req, res);
        return chefObj.logout();
    });

    app.use(config.baseApiUrl, router);
}