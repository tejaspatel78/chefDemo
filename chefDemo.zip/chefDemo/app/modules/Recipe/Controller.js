const Controller = require("../Base/Controller")
const _ = require("lodash")
const Recipe = require('./Schema').Recipe
const Chef = require('../Chef/Schema').Chef
const Model = require("../Base/Model")
const recipeProjection = require('./Projection')
const i18n = require("i18n")
const Moment = require('moment')


class RecipeController extends Controller {
    constructor() {
        super()
    }

    /********************************************************
    Purpose: Add recipe detail
    Parameter:
       {
            "title": "Cheesy Italiano MAGGI Noodles",
            "type": "LIVE_CLASS",
            "classDay": "2020-05-30",
            "classStartTime": "03:00 PM",
            "classLink": "www.chefcollective/2918476",
            "maxAttendees": 200,
            "level": "Beginner",
            "category": "noodles",
            "videoLink": "https://vimeo.com/71339660",
            "duration": "45 minutes",
            "ingredients": "ingredients",
            "equipments": "equipments",
            "method": "method",
            "description": "description",
            "recipeImage": "/eb3eeedac92150760491497/image_676736776674.jpeg"
        }
        ///////////////// or //////////////////
        {
            "title": "Veg pasta",
            "type": "VIDEO_RECIPE",
            "level": "Beginner",
            "category": "pasta",
            "videoLink": "https://vimeo.com/12239660",
            "duration": "45 minutes",
            "ingredients": "ingredients",
            "equipments": "equipments",
            "method": "method",
            "description": "description"
        }
    
    Return: JSON String
    ********************************************************/
    async createRecipe() {
        try {
            const reqPayload = this.req.body
            // if LIVE_CLASS then combine date and time
            if (reqPayload.type === 'LIVE_CLASS') {
                reqPayload.classStartTime = Moment(reqPayload.classDay + ' ' + reqPayload.classStartTime, 'YYYY-MM-DD hh:mm A')
                delete reqPayload.classDay
            }
            reqPayload.createdBy = this.req.currentUser && this.req.currentUser._id ? this.req.currentUser._id : ''
            // save new recipe detail
            const newRecipeDetail = await new Model(Recipe).store(reqPayload)
            // if recipe detail is empty give error message.
            if (_.isEmpty(newRecipeDetail)) {
                return this.res.send({ status: 0, message: i18n.__('RECIPE_NOT_SAVED') })
            }
            return this.res.send({ status: 1, message: i18n.__('RECIPE_CREATED_SUCCESSFULLY') })
        } catch (error) {
            console.log("Error while createRecipe(). Error = ", error)
            return this.res.send({ status: 0, message: error })
        }
    }

    /********************************************************
    Purpose: Get my recipes list
    Parameter:
    {
        page: 1,
        pagesize: 10,
        type: "LIVE_CLASS" / "VIDEO_RECIPE",
        sort: {
            title: 1
        },
        textsearch: "pizza medu"
    }
    Return: JSON String
    ********************************************************/
    async getMyRecipeList() {
        try {
            const payLoad = this.req.body
            const skip = (payLoad.page - 1) * (payLoad.pagesize)
            const sort = payLoad.sort ? payLoad.sort : { createdAt: -1 }
            const filterQuery = { type: this.req.body.type, createdBy: this.req.currentUser._id, isDeleted: false }
            // for search based on recipe
            if (payLoad.textsearch) {
                filterQuery.$text = { $search: payLoad.textsearch }
            }          
            const recipeList = await Recipe.find(filterQuery).sort(sort).skip(skip).limit(payLoad.pagesize).select(recipeProjection.recipeList)
            const recipeCount = await Recipe.find(filterQuery).countDocuments();
            return this.res.send({ status: 1, data: recipeList, total: recipeCount, message: i18n.__("FETCH_MY_RECIPE_SUCCESSFULLY") })
        } catch (error) {
            console.log("Error while getMyRecipeList(). Error = ", error)
            return this.res.send({ status: 0, message: error })
        }
    }

    /********************************************************
    Purpose: Edit recipe detail
    Parameter:
       {
            "recipeId": "5eb9641e553d582e00e52add"
            "title": "Cheesy Italiano MAGGI Noodles",
            "type": "LIVE_CLASS",
            "classDay": "2020-05-30",
            "classStartTime": "03:00 PM",
            "classLink": "www.chefcollective/2918476",
            "maxAttendees": 200,
            "level": "Beginner",
            "category": "noodles",
            "videoLink": "https://vimeo.com/71339660",
            "duration": "45 minutes",
            "ingredients": "ingredients",
            "equipments": "equipments",
            "method": "method",
            "description": "description",
            "recipeImage": "/eb3eeedac92150760491497/image_676736776674.jpeg"
        }
        ///////////////// or //////////////////
        {
            "recipeId": "5eb9641e553d582e00e52add"
            "title": "Veg pasta",
            "type": "VIDEO_RECIPE",
            "level": "Beginner",
            "category": "pasta",
            "videoLink": "https://vimeo.com/12239660",
            "duration": "45 minutes",
            "ingredients": "ingredients",
            "equipments": "equipments",
            "method": "method",
            "description": "description"
        }
    
    Return: JSON String
    ********************************************************/
    async updateRecipe() {
        try {
            const reqPayload = this.req.body
            // check recipe exist or not
            const recipe = await Recipe.findOne({ _id: reqPayload.recipeId, isDeleted: false })
            if (_.isEmpty(recipe)) {
                return this.res.send({ status: 0, message: i18n.__("RECIPE_NOT_FOUND") })
            }
            // if LIVE_CLASS then combine date and time
            if (reqPayload.type === 'LIVE_CLASS') {
                reqPayload.classStartTime = Moment(reqPayload.classDay + ' ' + reqPayload.classStartTime, 'YYYY-MM-DD hh:mm A')
                delete reqPayload.classDay
            }
            const updatedRecipe = await Recipe.findByIdAndUpdate(reqPayload.recipeId, reqPayload, { new: true }).select(recipeProjection.recipe)
            if (_.isEmpty(updatedRecipe)) {
                return this.res.send({ status: 0, message: i18n.__("RECIPE_NOT_UPDATED") })
            }
            return this.res.send({ status: 1, message: i18n.__("RECIPE_UPDATED_SUCCESSFULLY"), data: updatedRecipe })
        } catch (error) {
            console.log("Error while updateRecipe(). Error = ", error)
            this.res.send({ status: 0, message: i18n.__("SERVER_ERROR") })
        }
    }

    /********************************************************
    Purpose: Get recipe detail
    Path Parameter:
    {
        recipeId: "5eb9641e553d582e00e52att"
    }
    Return: JSON String
    ********************************************************/
    async getRecipeDetail() {
        try {
            const recipeDetail = await Recipe.findOne({ _id: this.req.params.recipeId, isDeleted: false }).populate('createdBy', { coverImage: 1, bio: 1, occupation: 1, photo: 1, firstname: 1, lastname: 1 }).select(recipeProjection.recipeDetail)
            if (_.isEmpty(recipeDetail)) {
                return this.res.send({ status: 0, message: i18n.__("RECIPE_NOT_FOUND") })
            }
            return this.res.send({ status: 1, message: i18n.__("RECIPE_DETAIL_FETCHED_SUCCESSFULLY"), data: recipeDetail })
        } catch (error) {
            console.log("Error while getRecipeDetail(). Error = ", error)
            return this.res.send({ status: 0, message: error })
        }
    }

    /********************************************************
    Purpose: Get explore recipes list
    Parameter:
    {
        page: 1,
        pagesize: 10,
        sort: {
            title: 1
        },
        type: "LIVE_CLASS" / "VIDEO_RECIPE", 
        filter: {
            level: ['Beginner', 'Intermediate', 'Advanced'],
            from: '2020-04-30',
            to: '2020-05-30'
        },
        textsearch: "ravi pizza medu"
    }
    Return: JSON String
    ********************************************************/
    async getExploreRecipeList() {
        try {
            const payLoad = this.req.body
            const skip = (payLoad.page - 1) * (payLoad.pagesize)
            const sort = payLoad.sort ? payLoad.sort : { createdAt: -1 }
            const filterQuery = { isDeleted: false, attendees: { $ne: this.req.currentUser._id }, createdBy: { $ne: this.req.currentUser._id } }
            
            // for search based on recipe and chef
            if (payLoad.textsearch) {
                const recipeSearchData = await Recipe.find({ $text: { $search: payLoad.textsearch } }).select({ _id: 1 })
                const chefSearchData = await Chef.find({ $text: { $search: payLoad.textsearch } }).select({ _id: 1 })
                const recipeSearchIds = recipeSearchData.map(obj => obj._id)
                const chefSearchIds = chefSearchData.map(obj => obj._id)
                filterQuery.$or = [{_id: { $in: recipeSearchIds}}, {createdBy: { $in: chefSearchIds }}]
            }
            if (payLoad.type) {
                filterQuery.type = payLoad.type
            }
            
            // for apply filter to the data
            if (payLoad.filter) {
                if (payLoad.filter.level) {
                    filterQuery.level = { $in: payLoad.filter.level }
                }
                if (payLoad.filter.from) {
                    filterQuery.createdAt = { $gte: Moment(payLoad.filter.from, 'YYYY-MM-DD') }
                }
                if (payLoad.filter.to) {
                    filterQuery.createdAt = { ...filterQuery.createdAt, $lt: Moment(payLoad.filter.to, 'YYYY-MM-DD').add(1, 'd') }
                }
            }
            const recipeList = await Recipe.find(filterQuery).sort(sort).skip(skip).limit(payLoad.pagesize).populate('createdBy', { photo: 1, firstname: 1, lastname: 1 }).select(recipeProjection.recipeList)
            const recipeCount = await Recipe.find(filterQuery).countDocuments();
            return this.res.send({ status: 1, data: recipeList, total: recipeCount, message: i18n.__("FETCH_EXPLORE_RECIPE_SUCCESSFULLY") })
        } catch (error) {
            console.log("Error while getExploreRecipeList(). Error = ", error)
            return this.res.send({ status: 0, message: error })
        }
    }

    /********************************************************
    Purpose: process for class interest
    Path Parameter:
    {
        recipeId: "5eb9641e553d582e00e52att"
    }
    Query Parameter:
    {
        interest: true (when want to book the live class) / false (when want to remove interest for live class)
    }
    Return: JSON String
    ********************************************************/
    async processClassInterest() {
        try {
            const key = this.req.query.interest === 'true' ? '$push' : '$pull'
            const response = await Recipe.update({ _id: this.req.params.recipeId }, { [key]: { attendees: this.req.currentUser._id } })
            if (response.nModified > 0) {
                return this.res.send({ status: 1, message: i18n.__("ATTENDEES_UPDATED_SUCCESSFULLY") })
            }
            return this.res.send({ status: 1, message: i18n.__("ATTENDEES_NOT_UPDATED") })
        } catch (error) {
            console.log("Error while processClassInterest(). Error = ", error)
            return this.res.send({ status: 0, message: error })
        }
    }

    /********************************************************
    Purpose: Get booked class list
    Parameter:
    {
        page: 1,
        pagesize: 10,
        type: "UPCOMING" / "COMPLETED",
        sort: {
            title: 1
        },
        textsearch: "ravi pizza medu"
    }
    Return: JSON String
    ********************************************************/
    async getBookedClassList() {
        try {
            const payLoad = this.req.body
            const skip = (payLoad.page - 1) * (payLoad.pagesize)
            const sort = payLoad.sort ? payLoad.sort : { createdAt: -1 }
            const filterQuery = { isDeleted: false, type: 'LIVE_CLASS', attendees: { $eq: this.req.currentUser._id }, createdBy: { $ne: this.req.currentUser._id } }
            
            // for search based on recipe and chef
            if (payLoad.textsearch) {
                const recipeSearchData = await Recipe.find({ $text: { $search: payLoad.textsearch } }).select({ _id: 1 })
                const chefSearchData = await Chef.find({ $text: { $search: payLoad.textsearch } }).select({ _id: 1 })
                const recipeSearchIds = recipeSearchData.map(obj => obj._id)
                const chefSearchIds = chefSearchData.map(obj => obj._id)
                filterQuery.$or = [{_id: { $in: recipeSearchIds}}, {createdBy: { $in: chefSearchIds }}]
            }
            
            let recipeList = await Recipe.find(filterQuery).select({ _id: 1, classStartTime: 1, duration: 1 })
            recipeList = recipeList.map(obj => {
                const duration = obj.duration.split(' ')
                if (payLoad.type === 'UPCOMING') {
                    if (Moment() < Moment(obj.classStartTime).add(Number(duration[0]), duration[1])) {
                        return obj._id
                    }
                } else if (payLoad.type === 'COMPLETED') {
                    if (Moment() >= Moment(obj.classStartTime).add(Number(duration[0]), duration[1])) {
                        return obj._id
                    }
                }
            })
            const bookedClassList = await Recipe.find({ _id: { $in: recipeList } }).sort(sort).skip(skip).limit(payLoad.pagesize).populate('createdBy', { photo: 1, firstname: 1, lastname: 1 }).select(recipeProjection.recipeList)
            const bookedClassCount = await Recipe.find({ _id: { $in: recipeList } }).countDocuments();
            return this.res.send({ status: 1, data: bookedClassList, total: bookedClassCount, message: i18n.__("BOOKED_CLASSES_FETCH_SUCCESSFULLY") })
        } catch (error) {
            console.log("Error while getBookedClassList(). Error = ", error)
            return this.res.send({ status: 0, message: error })
        }
    }
}

module.exports = RecipeController