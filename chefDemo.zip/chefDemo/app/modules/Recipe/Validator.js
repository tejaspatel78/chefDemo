/****************************
 Validators
 ****************************/
const i18n = require("i18n")
const {
    check,
    validationResult
} = require('express-validator')

class Validators {

    /********************************************************
    Purpose: Function for recipe body validator
    Parameter:
    {}
    Return: JSON String
    ********************************************************/
    static recipeBodyValidator() {
        try {
            return check('type')
            .exists()
            .withMessage(i18n.__("%s REQUIRED", 'type'))
            .custom((type, { req }) => {
                const keyArray = Object.keys(req.body)
                let requireKeys = ['title', 'level', 'category', 'videoLink']
                if (type === 'LIVE_CLASS') {
                    requireKeys = requireKeys.concat(['classDay', 'classStartTime', 'classLink', 'maxAttendees'])
                } else if (type === 'VIDEO_RECIPE') {
                    requireKeys = requireKeys.concat(['duration'])               
                } else {
                    return true
                } 
                const difference = requireKeys.filter(obj => !keyArray.includes(obj))
                if (difference.length > 0) {
                    throw new Error(i18n.__("%s REQUIRED", difference.toString()))
                }
                return true
            })
        } catch (error) {
            return error
        }
    }

    /********************************************************
    Purpose: Function for pagination body validator
    Parameter: {}
    Return: JSON String
    ********************************************************/
    static paginationBodyValidator() {
        try {
            return [
                check('page').exists().withMessage(i18n.__("%s REQUIRED", 'page')),
                check('pagesize').exists().withMessage(i18n.__("%s REQUIRED", 'pagesize'))
            ]
        } catch (error) {
            return error
        }
    }

    /********************************************************
    Purpose: Function for recipe list validator
    Parameter: {}
    Return: JSON String
    ********************************************************/
    static recipeListValidator() {
        try {
            return [
                check('page').exists().withMessage(i18n.__("%s REQUIRED", 'page')),
                check('pagesize').exists().withMessage(i18n.__("%s REQUIRED", 'pagesize')),
                check('type').exists().withMessage(i18n.__("%s REQUIRED", 'type'))    
            ]
        } catch (error) {
            return error
        }
    }

    /********************************************************
    Purpose: Function for recipeId validation
    Parameter: {}
    Return: JSON String
    ********************************************************/
    static recipeIdValidator() {
        try {
            return check('recipeId').exists().withMessage(i18n.__("%s REQUIRED", 'recipeId'))
        } catch (error) {
            return error
        }
    }
    
    /********************************************************
    Purpose: Function for class interest process validation
    Parameter: {}
    Return: JSON String
    ********************************************************/
    static classInterestProcessValidator() {
        try {
            return [
                check('recipeId').exists().withMessage(i18n.__("%s REQUIRED", 'recipeId')),
                check('interest').exists().withMessage(i18n.__("%s REQUIRED", 'interest'))
            ]
        } catch (error) {
            return error
        }
    }

    static validate(req, res, next) {
        try {
            const errors = validationResult(req)
            if (!errors.isEmpty()) {
                return res.status(422).json({
                    status: 0,
                    message: errors.array()
                })
            }
            next()
        } catch (error) {
            return res.send({
                status: 0,
                message: error
            })
        }
    }
}

module.exports = Validators