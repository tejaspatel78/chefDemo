
module.exports = (app, express) => {

    const router = express.Router()
    const Globals = require("../../../configs/Globals")
    const RecipeController = require('./Controller')
    const config = require('../../../configs/configs')
    const Validators = require("./Validator")

    router.post('/addRecipeDetail', Validators.recipeBodyValidator(), Globals.isAuthorised, Validators.validate, function (req, res) {
        const recipeObj = (new RecipeController()).boot(req, res)
        return recipeObj.createRecipe()
    })

    router.post('/getMyRecipeList', Validators.recipeListValidator(), Globals.isAuthorised, Validators.validate, function (req, res) {
        const recipeObj = (new RecipeController()).boot(req, res)
        return recipeObj.getMyRecipeList()
    })

    router.post('/updateRecipeDetail', Validators.recipeIdValidator(), Validators.recipeBodyValidator(), Globals.isAuthorised, Validators.validate, function (req, res) {
        const recipeObj = (new RecipeController()).boot(req, res)
        return recipeObj.updateRecipe()
    })

    router.get('/getRecipeDetail/:recipeId', Validators.recipeIdValidator(), Globals.isAuthorised, Validators.validate, function (req, res) {
        const recipeObj = (new RecipeController()).boot(req, res)
        return recipeObj.getRecipeDetail()
    })

    router.post('/getExploreRecipeList', Validators.paginationBodyValidator(), Globals.isAuthorised, Validators.validate, function (req, res) {
        const recipeObj = (new RecipeController()).boot(req, res)
        return recipeObj.getExploreRecipeList()
    })

    router.post('/process/classInterest/:recipeId', Validators.classInterestProcessValidator(), Globals.isAuthorised, Validators.validate, function (req, res) {
        const recipeObj = (new RecipeController()).boot(req, res)
        return recipeObj.processClassInterest()
    })

    router.post('/getBookedClassList', Validators.recipeListValidator(), Globals.isAuthorised, Validators.validate, function (req, res) {
        const recipeObj = (new RecipeController()).boot(req, res)
        return recipeObj.getBookedClassList()
    })

    app.use(config.baseApiUrl, router)
}