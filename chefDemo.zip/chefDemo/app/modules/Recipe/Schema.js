const mongoose = require('mongoose')
const schema = mongoose.Schema
const Schema = require('mongoose').Schema

const recipe = new schema({
    title: { type: String, required: true },
    type: { type: String, required: true },
    classStartTime: { type: Date },
    classLink: { type: String },
    maxAttendees: { type: Number },
    attendees: [{ type: Schema.Types.ObjectId, ref: 'Chef' }],
    recipeImage: { type: String },
    duration: { type: String },
    level: { type: String, required: true },
    category: { type: String, required: true },
    videoLink: { type: String, required: true },
    ingredients: { type: String },
    equipments: { type: String },
    method: { type: String },
    description: { type: String },
    isDeleted: { type: Boolean, default: false },
    createdBy: { type: Schema.Types.ObjectId, ref: 'Chef' },
}, {
        timestamps: true
    })


const Recipe = mongoose.model('Recipe', recipe)
module.exports = {
    Recipe
}