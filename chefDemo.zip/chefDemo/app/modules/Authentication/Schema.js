/**************************
 AUTHENTICATION SCHEMA INITIALISATION
 **************************/
const Schema = require('mongoose').Schema;
const mongoose = require('mongoose');

const authtokensSchema = new Schema({
    chefId: {
        type: Schema.Types.ObjectId,
        ref: 'Chef'
    },
    token: {
        type: Buffer
    },
    refreshToken: {
        type: Buffer
    },
    tokenExpiryTime: {
        type: Date
    }
}, {
    timestamps: true
});

const Authtokens = mongoose.model('authtokens', authtokensSchema);

module.exports = {
    Authtokens: Authtokens,
}