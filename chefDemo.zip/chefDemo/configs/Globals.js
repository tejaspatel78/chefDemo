/****************************
 SECURITY TOKEN HANDLING
 ****************************/
const Moment = require('moment');
const i18n = require("i18n");
const jwt = require('jsonwebtoken')
const config = require('./configs');
const Authentication = require('../app/modules/Authentication/Schema').Authtokens;
const Chef = require('../app/modules/Chef/Schema').Chef;

class Globals {

    // Generate Token
    getToken(params) {
        return new Promise(async (resolve, reject) => {
            try {
                // Generate Token
                const token = jwt.sign({
                    id: params.id,
                    algorithm: "HS256",
                    exp: Math.floor(Date.now() / 1000) + parseInt(config.tokenExpiry)
                }, config.securityToken);

                params.token = token;
                params.chefId = params.id;
                params.tokenExpiryTime = Moment().add(parseInt(config.tokenExpirationTime), 'minutes');
                delete params.id
                await Authentication.findOneAndUpdate({ chefId: params.chefId }, params, { upsert: true, new: true });
                return resolve(token);
            } catch (err) {
                console.log("Error while getToken(). Error =", err);
                return reject({ message: err, status: 0 });
            }
        });
    }
    
    // Generate Token
    getTokenWithRefreshToken(params) {
        return new Promise(async (resolve, reject) => {
            try {
                // Generate Token
                const token = jwt.sign({
                    id: params.id,
                    algorithm: "HS256",
                    exp: Math.floor(Date.now() / 1000) + parseInt(config.tokenExpiry)
                }, config.securityToken);

                // Generate refreshToken
                const refreshToken = jwt.sign({
                    id: params.id,
                    algorithm: "HS256",
                    exp: Math.floor(Date.now() / 1000) + parseInt(config.tokenExpiry)
                }, config.securityRefreshToken);

                params.token = token;
                params.chefId = params.id;
                params.refreshToken = refreshToken;
                params.tokenExpiryTime = Moment().add(parseInt(config.tokenExpirationTime), 'minutes');
                delete params.id;
                await Authentication.findOneAndUpdate({ chefId: params.chefId }, params, { upsert: true, new: true });
                return resolve({ token, refreshToken });
            } catch (err) {
                console.log("Error while getTokenWithRefreshToken(). Error =", err);
                return reject({ message: err, status: 0 });
            }
        });
    }

    generateToken(id) {
        return new Promise(async (resolve, reject) => {
            try {
                const token = jwt.sign({
                    id: id,
                    algorithm: "HS256",
                    exp: Math.floor(Date.now() / 1000) + parseInt(config.tokenExpiry)
                }, config.securityToken);

                return resolve(token);
            } catch (err) {
                console.log("Error while generateToken(). Error =", err);
                return reject({ message: err, status: 0 });
            }

        });
    }
    
    // Validating Token
    static async isAuthorised(req, res, next) {
        try {
            const token = req.headers.authorization;
            if (!token) return res.status(401).json({ status: 0, message: i18n.__("%s REQUIRED", 'Token') });
            
            const tokenCheck = await new Globals().checkTokenInDB(token);
            if (!tokenCheck) return res.status(401).json({ status: 0, message: i18n.__("INVALID_TOKEN") });

            const tokenExpire = await new Globals().checkExpiration(token);
            if (!tokenExpire) return res.status(401).json({ status: 0, message: i18n.__("TOKEN_EXPIRED") });

            const userExist = await new Globals().checkUserInDB(token);
            if (!userExist) return res.status(401).json({ status: 0, message: i18n.__("USER_NOT_EXIST_FOR_APPLIED_TOKEN") });

            if (userExist._id) {
                req.currentUser = userExist;
                if (config.extendTokenTime && config.extendTokenTime === 'true') {
                    await new Globals().extendTokenTime(userExist._id);
                }
            }
            next();
        } catch (err) {
            console.log("Error while isAuthorised(). Error =", err);
            return res.send({ status: 0, message: err });
        }
    }

    async extendTokenTime(userId) {
        return new Promise(async (resolve, reject) => {
            try {
                const authenticate = await Authentication.findOne({ userId: userId });
                if (authenticate && authenticate.tokenExpiryTime) {
                    const expiryDate = Moment(authenticate.tokenExpiryTime).subtract(2, 'minutes')
                    const now = Moment();
                    if (now > expiryDate) {
                        await Authentication.findOneAndUpdate({ userId: userId }, { tokenExpiryTime: Moment(authenticate.tokenExpiryTime).add(parseInt(config.tokenExpirationTime), 'minutes') });
                    }
                }
                return resolve();
            } catch (error) {
                reject(error);
            }
        });
    }

    // Check User Existence in DB
    checkUserInDB(token) {
        return new Promise(async (resolve, reject) => {
            try {
                const decoded = jwt.decode(token);
                if (!decoded) { return resolve(false); }
                const chef = await Chef.findOne({ _id: decoded.id, isDeleted: false, status: true });
                if (chef) return resolve(chef);
                return resolve(false);
            } catch (err) {
                console.log('Error while checkUserInDB(). Error =', err)
                return reject({ message: err, status: 0 });
            }

        })
    }

    // Check token in DB
    checkTokenInDB(token) {
        return new Promise(async (resolve, reject) => {
            try {
                const tokenDetails = Buffer.from(token, 'binary').toString();
                const verified = jwt.verify(tokenDetails, config.securityToken);
                if (!verified) return resolve(false)
                const authenticate = await Authentication.findOne({ token: tokenDetails });
                if (authenticate) return resolve(true);
                return resolve(false);
            } catch (err) {
                console.log('Error while checkTokenInDB(). Error =', err)
                return reject({ message: err, status: 0 });
            }
        })
    }

    // Check Token Expiration
    checkExpiration(token) {
        return new Promise(async (resolve, reject) => {
            const tokenDetails = Buffer.from(token, 'binary').toString();
            let status = false;
            const authenticate = await Authentication.findOne({ token: tokenDetails });
            if (authenticate && authenticate.tokenExpiryTime) {
                const expiryDate = Moment(authenticate.tokenExpiryTime, 'YYYY-MM-DD HH:mm:ss')
                const now = Moment(new Date(), 'YYYY-MM-DD HH:mm:ss');
                if (expiryDate > now) { status = true; resolve(status); }
            }
            resolve(status);
        })
    }

    static decodeChefForgotToken(data) {
        return new Promise(async (resolve, reject) => {
            if (data && data.forgotTokenCreationTime && parseInt(config.forgotTokenExpireTime)) {
                const expiryDate = Moment(data.forgotTokenCreationTime).add(parseInt(config.forgotTokenExpireTime), 'minutes');
                const now = Moment();
                if (expiryDate < now) {
                    return resolve(false);
                }
            }
            return resolve(true);
        });
    }
    static decodeChefVerificationToken(data) {
        return new Promise(async (resolve, reject) => {
            if (data && data.verificationTokenCreationTime && parseInt(config.verificationTokenExpireTime)) {
                const expiryDate = Moment(data.verificationTokenCreationTime).add(parseInt(config.verificationTokenExpireTime), 'minutes');
                const now = Moment();
                if (expiryDate < now) {
                    return resolve(false);
                }
            }
            return resolve(true);
        });
    }
}

module.exports = Globals;
